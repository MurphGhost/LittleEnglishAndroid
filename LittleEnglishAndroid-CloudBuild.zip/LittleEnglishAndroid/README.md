# Little English Android — 手机一键云端编译版

这是从原 `grok-workspace.zip` 的已编译 Web 前端资源封装成的 Android APK 工程。

## 手机上怎么生成 APK

推荐使用 GitHub Actions，不需要电脑、不需要 Android Studio。

1. 在 GitHub 新建一个**空的公开仓库**（Private 也可以，但 GitHub Actions 使用情况取决于账号额度）。
2. 把本工程里的全部文件上传到仓库根目录，确保 `.github/workflows/build-apk.yml` 也上传进去。
3. 上传完成后进入仓库 → **Actions** → **Build Android APK** → **Run workflow**。
4. 等待构建完成后点进去 → **Artifacts** → 下载 `LittleEnglish-APK`。
5. 手机上解压下载的 ZIP，里面的 `LittleEnglish.apk` 就可以直接安装。

也可以直接修改任意文件并 push 到 `main`，它会自动构建。

## 构建环境

- Android Gradle Plugin 8.7.3
- Gradle 8.10.2
- JDK 17
- Android SDK 35
- 输出：Debug APK（可直接安装）

## 注意

首次安装时 Android 可能提示“允许安装未知来源应用”，按系统提示允许即可。
